# Search Demand Research Methodology and Query Bank

## Purpose

This file converts broad relocation curiosity into measurable demand signals. It should be used when collecting Google Trends, Google Keyword Planner, Ahrefs, Semrush, Similarweb or Search Console data.

## Important data rule

Google Trends is useful for direction, timing and geographic comparison, but it does not provide absolute search volume. Google states that Trends data are normalised by geography and time range, then scaled so values can be compared. Therefore, a Trends value is not the number of searches. Use Keyword Planner or SEO tools for approximate monthly search volume.

## Minimum tools

1. **Google Trends** — relative demand, geography, timing, seasonality.
2. **Google Trends API alpha** — when access is available, useful for consistent programmatic data over the recent 5-year window.
3. **Google Keyword Planner** — approximate search volume and forecasts.
4. **Ahrefs / Semrush / Similarweb** — keyword volume, keyword difficulty, traffic estimates, competitor pages.
5. **YouTube search / YouTube analytics tools** — video demand and creator ecosystem.
6. **Reddit / Telegram / Facebook group sampling** — qualitative pain signals.

## Core keyword groups

### 1. General migration intent
- move abroad
- move overseas
- immigrate to another country
- how to move abroad
- best countries to live in
- best countries for expats
- cheapest countries to live in
- safest countries to live in
- easiest countries to immigrate to
- countries with easy residency

### 2. Visa and residence intent
- residence permit
- permanent residence
- temporary residence permit
- digital nomad visa
- remote worker visa
- startup visa
- investor visa
- work visa
- family reunification visa
- student visa stay after graduation

### 3. Citizenship and passport intent
- second passport
- dual citizenship
- citizenship by investment
- citizenship by descent
- fastest citizenship countries
- easy citizenship countries
- naturalisation requirements
- passport ranking
- visa free countries by passport

### 4. Financial and business migration
- best country to start a business
- low tax countries
- tax residency abroad
- territorial tax countries
- offshore company formation
- countries with low corporate tax
- best countries for entrepreneurs
- best startup visa countries
- bank account for non residents

### 5. Practical relocation problems
- cost of living in [country]
- rent in [city]
- healthcare in [country]
- schools in [country]
- crime rate in [city]
- expat jobs in [country]
- open bank account in [country]
- how to get tax number in [country]
- moving checklist [country]

### 6. Fear / risk queries
- is [country] safe
- is [city] safe
- corruption in [country]
- bureaucracy in [country]
- racism in [country]
- visa denial [country]
- tax problems in [country]
- political situation in [country]
- property rights in [country]

## Country-intent templates

Use these templates for every priority country:

- move to [country]
- immigrate to [country]
- [country] residence permit
- [country] permanent residency
- [country] citizenship
- [country] digital nomad visa
- [country] startup visa
- [country] taxes for expats
- [country] cost of living
- [country] vs [country]
- living in [country] as a foreigner
- expat problems in [country]
- how to open company in [country]
- how to open bank account in [country]

## Initial priority country pairs for comparison research

- Portugal vs Spain
- Uruguay vs Argentina
- Uruguay vs Paraguay
- Argentina vs Paraguay
- Portugal vs Uruguay
- Spain vs Portugal
- Canada vs Australia
- Canada vs Germany
- Serbia vs Georgia
- Georgia vs Armenia
- UAE vs Portugal
- Mexico vs Costa Rica
- Chile vs Uruguay
- Netherlands vs Germany
- Turkey vs Georgia

## Output table to collect

| Keyword | Country/region | Tool | Relative trend | Monthly volume | CPC | Competition | 12-month change | 5-year change | Notes |
|---|---|---|---:|---:|---:|---|---:|---:|---|

## Decision rules

1. If search volume is high but competitor quality is low, this is a strong content opportunity.
2. If search volume is medium but user risk is high, this may still be a strong premium-product opportunity.
3. If a country has rising search interest and recent visa/legal changes, it should be added to the watchlist.
4. If social-media discussion grows before Google volume grows, treat it as an early signal.
5. If many queries include “vs”, users need comparison, not just articles.
6. If many queries include “safe”, “tax”, “visa denial”, “bank account” or “documents”, users need risk-reduction tools.

## Recommended search-demand deliverable

Create a spreadsheet with:

1. 300-500 keywords.
2. 15-25 countries.
3. 20-30 country-pair comparisons.
4. Separate tabs for B2C migration, digital nomads, investors, students, families and business formation.
5. A final priority score: `Demand x Pain x Monetisation x Data Availability`.
