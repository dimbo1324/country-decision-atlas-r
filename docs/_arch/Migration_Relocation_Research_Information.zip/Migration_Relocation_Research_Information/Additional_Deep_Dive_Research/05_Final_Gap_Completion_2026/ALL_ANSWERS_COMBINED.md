# Final Gap Completion Research Pack 2026

**Research date:** 2026-06-17  
**Purpose:** close the remaining practical research gaps in the Migration / Relocation / Country Choice mega-archive.

This folder adds the missing applied materials that were not fully covered by the previous research archive:

1. Final gap assessment and readiness status.
2. Top 50 competitor feature matrix.
3. Search-demand methodology and keyword bank.
4. User research interview and survey pack.
5. Legal source map for priority countries.
6. Monetisation benchmark and pricing signals.
7. Country risk / direction index methodology.
8. MVP readiness decision memo.
9. Source index with official and high-confidence references.

## Important limitation

This pack closes the desk-research gaps. It cannot replace:

- paid SEO exports from Ahrefs / Semrush / Similarweb / Google Keyword Planner;
- direct interviews with migrants, expats, investors, students and digital nomads;
- legal advice from regulated professionals;
- continuous monitoring of fast-changing immigration, visa and tax rules.

Therefore, the research base is now sufficient for product strategy and MVP planning, but user interviews and live search-demand exports should be collected before serious monetisation decisions.


---


# Final Gap Assessment and Research Completion Status

## Executive conclusion

The archive is now strong enough to move from broad research into product strategy, MVP definition and data modelling. The remaining gaps were not missing general knowledge; they were applied product-research artefacts:

- a competitor feature matrix;
- a source map for official legal and immigration information;
- a repeatable method for search-demand measurement;
- a user-research plan;
- a monetisation benchmark;
- a methodology for country direction/risk scoring.

These gaps are addressed in this final folder.

## Updated readiness estimate

| Research area | Previous readiness | Updated readiness after this pack | Notes |
|---|---:|---:|---|
| General migration trends | 90-95% | 95% | Macro data is current enough for product framing. |
| Migration interest / demand | 85-90% | 90% | Still needs paid/raw keyword volume for exact prioritisation. |
| Competitor landscape | 80-85% | 90% | Top 50 feature matrix added. |
| Monetisation | 75-80% | 85-90% | Pricing signals and model logic added; many B2B prices remain sales-gated. |
| Legal / visa data source map | 75-80% | 90% | Priority-country source map added; requires ongoing monitoring. |
| User pain research | 75-80% | 85% | Interview/survey pack added; real interviews still required. |
| Country direction / risk methodology | 80% | 90% | Scoring framework added. |
| MVP readiness | 80-85% | 90% | Ready for product strategy and technical specification. |

## What can be considered sufficiently covered

1. Global migration direction and macro drivers.
2. Main reasons people consider migration and relocation.
3. Online interest and search-demand categories.
4. Social/community channels where relocation decisions are discussed.
5. Main competitor categories.
6. Core product opportunity: combine objective data, legal signals, human experience and scenario-based decision support.
7. Initial MVP scope: limited set of countries, user scenarios, country cards, comparison dashboard, legal signals and user-experience layer.

## What still cannot be closed by desk research alone

### 1. Real willingness to pay
Desk research shows what platforms charge and where money flows, but it cannot prove that users will pay for a new product. This needs interviews, landing-page tests, waitlists, paid report pre-sales or concierge MVP experiments.

### 2. Exact search volume
Google Trends gives relative interest, not absolute search volume. Exact keyword-volume work needs Google Keyword Planner, Google Ads API, Ahrefs, Semrush, Similarweb or another paid SEO dataset.

### 3. Legal accuracy at launch
A product using visa, residence, citizenship and tax data needs a review workflow. Official sources must be linked, date-stamped and verified regularly. Legal information should be presented as informational, not as legal advice.

### 4. Community data quality
Forum-like platforms become noisy unless the product forces structured experience submission, verification markers, reputation signals and strict moderation.

## Final recommendation

Stop broad information collection and move to a product strategy document.

Recommended next deliverables:

1. Product Strategy Document.
2. MVP Specification.
3. Data Model / Entity Relationship Draft.
4. OpenAPI Contract Draft.
5. UX sitemap and first wireframes.
6. Interview script execution with 20-50 real users.


---


# Top 50 Competitor Feature Matrix

**Purpose:** identify which functions are already covered by existing platforms and where a new country-choice / relocation-intelligence product can differentiate.

**How to read this matrix:**

- “Comparison” means a platform supports meaningful country/city/passport/program comparison.
- “Community” means users can publish experience, reviews, posts, comments or forum answers.
- “Legal tracking” means the platform monitors laws, visa rules, policy changes, regulations or legal databases in a systematic way.
- “Reuse signal” identifies what can be ethically learned from the product pattern without copying the product.

## Matrix

| # | Platform | Category | Primary user | Core job | Key strength | Main weakness / gap | Comparison | Community | Legal tracking | Monetisation | Reuse signal |
|---:|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Google Search | General discovery | Anyone researching relocation | Find scattered information quickly | Universal reach, fresh SERPs | No structured decision workflow; high noise | No | No | No | Ads | SEO demand and source-discovery logic |
| 2 | YouTube | Video experience | Migrants, nomads, travellers | Understand lived experience visually | High trust through personal stories | Subjective, not structured, hard to compare | No | Creator comments | No | Ads / creator monetisation | Video evidence layer and creator-source ingestion |
| 3 | Reddit | Community Q&A | Relocants, expats, nomads | Ask real people niche questions | Authentic discussions, long-tail problems | Unverified, biased, often contradictory | No | Yes | No | Ads / premium | Pain mining and structured Q&A ideas |
| 4 | Telegram | Community/chat | Migrants by country/language | Get fast local updates | Real-time informal info | Hard to search, noisy, unverifiable | No | Yes | No | Mostly indirect | Early-warning social signal source |
| 5 | Facebook Groups | Community | Local expats and migrants | Find groups, housing, advice | Large local groups | Fragmented, moderation varies | No | Yes | No | Ads | Local community segmentation |
| 6 | Google Maps | Local discovery | Travellers, movers, families | Evaluate neighbourhoods and services | Local reviews, maps, infrastructure | Not relocation-specific | Partial | Reviews | No | Ads/local listings | Neighbourhood evidence layer |
| 7 | Wikipedia | Reference | General researchers | Understand country basics | Broad coverage, citations | Not personalised or current enough | No | No | Partial law links | Donations | Country profile baseline |
| 8 | TripAdvisor | Travel reviews | Travellers, short-term visitors | Assess places and services | Large review base | Tourism-biased | No | Reviews | No | Ads/booking affiliate | Review trust mechanics |
| 9 | Booking.com | Accommodation marketplace | Travellers, temporary movers | Book temporary housing | Inventory and reviews | Not long-term relocation logic | No | Reviews | No | Commission | Short-stay relocation bridge |
| 10 | Airbnb | Accommodation marketplace | Travellers, nomads, trial movers | Test living in a place | Neighbourhood and lifestyle signals | Expensive, short-term bias | No | Reviews | No | Commission | Try-before-moving journey |
| 11 | Nomads.com / Nomad List | Digital nomad city ranking | Digital nomads, remote workers | Choose city to live/work remotely | Strong city filters, community, travel tracking | Nomad-focused, not full migration/law platform | Yes | Community | Limited / user reports | Membership + ads | Interactive scoring, filters, calendar/residency alerts |
| 12 | Numbeo | Cost/quality database | Individuals, researchers, organisations | Compare cost of living and quality indicators | Massive crowdsourced price database | Crowdsourced accuracy varies; no personal scenario | Yes | Data contributors | No | Ads/API/data products | Crowdsourced quantitative indicators |
| 13 | Expatistan | Cost of living | Expats, movers | Compare city costs | Simple cost comparison | Limited broader country-choice depth | Yes | Contributors | No | Ads/data | Cost-comparison simplicity |
| 14 | Livingcost.org | Cost of living | Expats, students, travellers | Estimate living costs | Simple country/city cost data | Limited legal/community layer | Yes | Limited | No | Ads | Low-friction benchmark pages |
| 15 | MyLifeElsewhere | Country comparison | General users | Compare countries and cities | Accessible comparative format | Not deep enough for serious decisions | Yes | No | No | Ads | Friendly comparison UX |
| 16 | Teleport Cities | City matching | Tech workers, movers | Choose city for career/lifestyle | Personal city matching and quality metrics | Limited coverage/current activity | Yes | No | No | Previously SaaS/ecosystem | Scenario matching idea |
| 17 | The Earth Awaits | Budget-based city search | Budget-conscious movers | Find places by budget and preferences | Clear budget-first filters | Limited legal/community data | Yes | No | No | Likely ads/donations | Budget-first exploration |
| 18 | Where Can I Live | Immigration pathways | Individuals seeking visa/residence options | Find where one can live by passport/status | Strong immigration-pathway framing | Data freshness/coverage must be checked | Yes | No | Immigration info | Content/affiliate/services | Passport-to-residence eligibility logic |
| 19 | VisaGuide.World | Visa information | Travellers and migrants | Understand visa requirements | Broad visa guides and news | Information guide, not personalised platform | Partial | No | Visa/news updates | Ads/affiliate possible | Visa guide content structure |
| 20 | VisaDB | Visa database | Travellers, nomads | Check visa options and travel freedom | Structured visa database | Limited decision/intelligence layer | Yes | No | Visa data | Subscription/paid access historically | Visa filters |
| 21 | iVisa | Visa processing | Travellers | Apply for visas/eVisas online | Transactional visa application flow | Travel-document focus, not country choice | No | Reviews | No | Service fees | Document/application workflow |
| 22 | Atlys | Visa processing app | Travellers | Apply for visas via mobile-first process | Strong UX around visa application | Not broad relocation strategy | No | Reviews | No | Service fees | Mobile-first document flow |
| 23 | Sherpa | Travel requirements API | Travellers, airlines, travel companies | Check entry requirements | Strong B2B/API travel compliance | Short-term travel focus | No | No | Entry rules | B2B/API | Rules engine and API model |
| 24 | VFS Global | Visa centres | Visa applicants, governments | Submit applications/biometrics | Official outsourced visa infrastructure | Not advisory/comparison product | No | No | No | Government/consular contracts + fees | Appointment/document workflow |
| 25 | TLScontact | Visa centres | Visa applicants, governments | Visa appointments and processing support | Official consular process layer | Not decision-support | No | No | No | Service fees/contracts | Operational workflow model |
| 26 | Passport Index | Passport ranking | Travellers, mobility researchers | Compare passport mobility | Interactive passport ranking | Mobility only, not relocation suitability | Yes | No | No | Data/brand/ads | Passport power visualisation |
| 27 | Henley Passport Index | Passport ranking | Investors, advisors, researchers | Assess passport mobility | Authoritative passport ranking; 199 passports/227 destinations | Not broader country-choice tool | Yes | No | No | Reports/advisory ecosystem | Mobility index methodology |
| 28 | Henley & Partners | Investment migration advisory | HNWIs, investors | Residence/citizenship by investment | Strong brand, legal/advisory network | High-net-worth niche | No | No | Legal/advisory | Consulting/advisory fees | Premium advisory/report model |
| 29 | Global Citizen Solutions | Investment migration/advisory | Investors, expats | Compare residence/citizenship investment options | Country reports and advisory content | Investor-heavy bias | Partial | No | Program updates | Consulting/reports | Report-led funnel |
| 30 | Nomad Capitalist | Tax/global strategy advisory | Entrepreneurs, HNWIs | Tax, residence, second citizenship strategy | Strong positioning and content marketing | Premium niche, opinionated framing | No | No | Legal/tax content | Consulting/programs | Strategic persona-driven messaging |
| 31 | Citizen Remote | Digital nomad relocation | Remote workers | Get visa and relocation support | End-to-end support across 30+ countries | Remote-worker focus, not universal country atlas | Partial | Testimonials | Visa assistance | Consultations/services | Concierge + platform hybrid |
| 32 | Nomad Embassy | Digital nomad visas | Remote workers | Understand and apply for nomad visas | Clear nomad visa content | Niche to nomads | Partial | No | Visa updates | Affiliate/services | Visa programme comparison |
| 33 | Digital Nomads World | Nomad community/content | Digital nomads | Find guides, community and resources | Lifestyle/community angle | Less rigorous data layer | Partial | Community | No | Membership/ads/affiliate | Community editorial packaging |
| 34 | Freaking Nomads | Nomad media/tools | Digital nomads | Learn destinations and nomad tools | Good content brand | Media not data platform | Partial | No | Visa content | Ads/affiliate | Content funnel ideas |
| 35 | InterNations | Expat community | Expats in major cities | Meet people, events, tips | 420 cities; large trusted network | Community-first, limited structured analytics | No | Yes | No | Freemium/premium events/membership | Trusted community and events model |
| 36 | Expat.com | Expat community/services | Expats and recruiters | Ask questions, read guides, find jobs/housing | Community + jobs + housing + guides | Not deep decision intelligence | Partial | Yes | Visa/life guides | Ads/classifieds/jobs | Multi-sided expat portal model |
| 37 | Expat Exchange | Expat community/content | Expats, retirees | Read country guides and discussions | Long-lived expat knowledge base | Older UX, unstructured content | Partial | Yes | No | Ads/sponsorship | Forum archive value |
| 38 | Expat Forum | Forum | Expats and migrants | Discuss country-specific issues | Focused threads by destination | Noise and outdated posts | No | Yes | No | Ads | Thread taxonomy |
| 39 | Expatica | Country guides/media | Expats in Europe and beyond | Understand visas, housing, healthcare, work | Strong guide format | Content-heavy, not interactive enough | Partial | Limited | Policy/news content | Ads/affiliate | Guide architecture |
| 40 | Expat Arrivals | Country/city guides | Families, expats, employers | Prepare relocation with practical guides | Good practical relocation categories | Limited dynamic scoring | Partial | No | No | Content/business services | Guide taxonomy for families/schools |
| 41 | MoveHub | Moving guides | People moving abroad | Plan move and estimate costs | Accessible relocation content | Not legal-intelligence platform | Partial | No | No | Lead generation/affiliate | Moving-cost funnel |
| 42 | Just Landed | Expat classifieds/guides | Expats | Find housing/jobs/services and advice | Broad expat portal | Fragmented/old UX | Partial | Community | No | Ads/classifieds | Classifieds plus guide model |
| 43 | International Living | Retirement abroad media | Retirees, lifestyle migrants | Identify retirement destinations | Strong niche editorial reports | Retirement/lifestyle bias | Partial | Community/content | No | Subscriptions/reports | Niche audience packaging |
| 44 | World Bank Data | Open data | Researchers, analysts | Get global indicators | Authoritative indicators/API | Not user-friendly decision product | Yes via data | No | No | Public/open | Objective data layer |
| 45 | OECD Better Life Index | Quality of life index | Researchers, public users | Compare wellbeing dimensions | Clear QOL framework | OECD-only coverage | Yes | No | No | Public/open | Indicator category design |
| 46 | Our World in Data | Data visualisation | Researchers, public users | Understand global trends | Excellent charts and transparent sources | Not relocation-specific | Yes via charts | No | No | Donations/grants | Data storytelling |
| 47 | Freedom House | Freedom/democracy index | Researchers, policy users | Assess political rights/civil liberties | Trusted freedom indicators | Not personalised/migration-specific | Yes via scores | No | No | Grants/reports | Freedom score integration |
| 48 | V-Dem | Democracy dataset | Researchers, analysts | Measure democracy/autocracy trends | Deep longitudinal democracy indicators | Complex for consumers | Yes via data | No | No | Research/open data | Country drift methodology |
| 49 | World Justice Project | Rule of law index | Researchers, investors, policy users | Assess rule of law | Strong legal/institutional indicators | Annual, not user-specific | Yes | No | No | Reports/grants | Rule-of-law indicator integration |
| 50 | Transparency International CPI | Corruption index | Public, business, policy users | Assess perceived corruption | Recognised corruption benchmark | Annual and broad | Yes | No | No | Nonprofit/reports | Corruption risk indicator |
| 51 | Economist Intelligence Unit | Country intelligence | Businesses, investors | Analyse country risk, politics, economy | High-quality expert analysis | Expensive, B2B/professional | Yes/reports | No | Policy/economy | Subscriptions/reports | Premium country intelligence format |
| 52 | International SOS | Travel risk/assistance | Corporations, travellers | Manage health/security risk | Operational risk intelligence and assistance | B2B travel-risk focus | Yes/risk | No | Alerts | Enterprise subscription/services | Risk-alert model |
| 53 | Crisis24 | Risk intelligence | Corporations, security teams | Monitor security/travel risks | Real-time alerts and country risk | Enterprise/security focus | Yes/risk | No | Alerts | Enterprise subscription | Alerting and incident feed |
| 54 | FiscalNote / PolicyNote | Policy intelligence | Government affairs teams | Track legislation/regulation and policy changes | AI-driven policy tracking, alerts, API | Enterprise; not relocation-specific | No | No | Yes | Enterprise subscription/API | Legal signal architecture |
| 55 | Quorum | Public affairs software | Policy/public affairs teams | Track legislation and execute advocacy | AI public-affairs workflow, stakeholder tools | Enterprise; not consumer relocation | No | No | Yes | Enterprise subscription | Policy workflow and alerts |
| 56 | LexisNexis | Legal research | Lawyers, compliance teams | Research law and legal/compliance data | Authoritative legal database | Expensive/professional; not consumer UX | No | No | Yes | Subscription | Legal citation/source discipline |

## Main pattern found

No single platform fully combines all of these layers:

1. objective country indicators;
2. visa/residence/citizenship pathways;
3. legal and policy change tracking;
4. structured human relocation experience;
5. personalised scenario matching;
6. explainable scoring;
7. country direction/drift over time;
8. evidence-backed source links;
9. alerts and watchlists.

The strongest product gap remains a hybrid platform that treats country choice as a decision-support workflow, not as a static article, forum, cost table or visa-service funnel.


---


# Search Demand Research Methodology and Query Bank

## Purpose

This file converts broad relocation curiosity into measurable demand signals. It should be used when collecting Google Trends, Google Keyword Planner, Ahrefs, Semrush, Similarweb or Search Console data.

## Important data rule

Google Trends is useful for direction, timing and geographic comparison, but it does not provide absolute search volume. Google states that Trends data are normalised by geography and time range, then scaled so values can be compared. Therefore, a Trends value is not the number of searches. Use Keyword Planner or SEO tools for approximate monthly search volume.

## Minimum tools

1. **Google Trends** — relative demand, geography, timing, seasonality.
2. **Google Trends API alpha** — when access is available, useful for consistent programmatic data over the recent 5-year window.
3. **Google Keyword Planner** — approximate search volume and forecasts.
4. **Ahrefs / Semrush / Similarweb** — keyword volume, keyword difficulty, traffic estimates, competitor pages.
5. **YouTube search / YouTube analytics tools** — video demand and creator ecosystem.
6. **Reddit / Telegram / Facebook group sampling** — qualitative pain signals.

## Core keyword groups

### 1. General migration intent
- move abroad
- move overseas
- immigrate to another country
- how to move abroad
- best countries to live in
- best countries for expats
- cheapest countries to live in
- safest countries to live in
- easiest countries to immigrate to
- countries with easy residency

### 2. Visa and residence intent
- residence permit
- permanent residence
- temporary residence permit
- digital nomad visa
- remote worker visa
- startup visa
- investor visa
- work visa
- family reunification visa
- student visa stay after graduation

### 3. Citizenship and passport intent
- second passport
- dual citizenship
- citizenship by investment
- citizenship by descent
- fastest citizenship countries
- easy citizenship countries
- naturalisation requirements
- passport ranking
- visa free countries by passport

### 4. Financial and business migration
- best country to start a business
- low tax countries
- tax residency abroad
- territorial tax countries
- offshore company formation
- countries with low corporate tax
- best countries for entrepreneurs
- best startup visa countries
- bank account for non residents

### 5. Practical relocation problems
- cost of living in [country]
- rent in [city]
- healthcare in [country]
- schools in [country]
- crime rate in [city]
- expat jobs in [country]
- open bank account in [country]
- how to get tax number in [country]
- moving checklist [country]

### 6. Fear / risk queries
- is [country] safe
- is [city] safe
- corruption in [country]
- bureaucracy in [country]
- racism in [country]
- visa denial [country]
- tax problems in [country]
- political situation in [country]
- property rights in [country]

## Country-intent templates

Use these templates for every priority country:

- move to [country]
- immigrate to [country]
- [country] residence permit
- [country] permanent residency
- [country] citizenship
- [country] digital nomad visa
- [country] startup visa
- [country] taxes for expats
- [country] cost of living
- [country] vs [country]
- living in [country] as a foreigner
- expat problems in [country]
- how to open company in [country]
- how to open bank account in [country]

## Initial priority country pairs for comparison research

- Portugal vs Spain
- Uruguay vs Argentina
- Uruguay vs Paraguay
- Argentina vs Paraguay
- Portugal vs Uruguay
- Spain vs Portugal
- Canada vs Australia
- Canada vs Germany
- Serbia vs Georgia
- Georgia vs Armenia
- UAE vs Portugal
- Mexico vs Costa Rica
- Chile vs Uruguay
- Netherlands vs Germany
- Turkey vs Georgia

## Output table to collect

| Keyword | Country/region | Tool | Relative trend | Monthly volume | CPC | Competition | 12-month change | 5-year change | Notes |
|---|---|---|---:|---:|---:|---|---:|---:|---|

## Decision rules

1. If search volume is high but competitor quality is low, this is a strong content opportunity.
2. If search volume is medium but user risk is high, this may still be a strong premium-product opportunity.
3. If a country has rising search interest and recent visa/legal changes, it should be added to the watchlist.
4. If social-media discussion grows before Google volume grows, treat it as an early signal.
5. If many queries include “vs”, users need comparison, not just articles.
6. If many queries include “safe”, “tax”, “visa denial”, “bank account” or “documents”, users need risk-reduction tools.

## Recommended search-demand deliverable

Create a spreadsheet with:

1. 300-500 keywords.
2. 15-25 countries.
3. 20-30 country-pair comparisons.
4. Separate tabs for B2C migration, digital nomads, investors, students, families and business formation.
5. A final priority score: `Demand x Pain x Monetisation x Data Availability`.


---


# User Research Interview and Survey Pack

## Purpose

Desk research cannot prove real willingness to pay or reveal the exact decision workflow of migrants, expats, investors, families and digital nomads. This pack is designed to collect primary research.

## Target respondent groups

1. People who moved abroad in the last 24 months.
2. People currently planning a move within 12 months.
3. People who considered moving but postponed or cancelled the plan.
4. Digital nomads and remote workers.
5. Families with children.
6. Students planning international education.
7. Entrepreneurs/investors considering company formation, tax residence or second citizenship.
8. HR/global mobility professionals.
9. Immigration lawyers/consultants.
10. Expats who moved more than once.

## Interview sample target

Minimum useful sample:

- 20 in-depth interviews for first insight.
- 50 interviews for stronger patterns.
- 100+ survey responses for prioritisation.

## Interview script

### Section A — Background
1. Which country are you from?
2. Which country did you move to, or are you considering moving to?
3. What was your main reason for considering relocation?
4. Did you move alone, with a partner, with children, or as part of work relocation?
5. What was your budget and expected monthly cost of living?

### Section B — Decision process
6. When did you first start thinking seriously about moving?
7. What was the first thing you searched for?
8. Which websites, platforms, chats or channels did you use?
9. Which sources felt trustworthy?
10. Which sources felt confusing, outdated or biased?
11. Which countries did you compare?
12. What were your top three decision criteria?
13. What information was hardest to find?
14. What information was easy to find but hard to trust?

### Section C — Legal and document friction
15. Which visa/residence/citizenship route did you consider?
16. What legal or document requirements were unclear?
17. Did rules change during your planning process?
18. Did you use a lawyer or consultant?
19. How much did you pay for professional help?
20. What would you have wanted to verify before paying?

### Section D — Real-life experience after relocation
21. What was different from what you expected?
22. What was more expensive than expected?
23. What was easier than expected?
24. What was the biggest mistake you made?
25. What advice would you give to someone like you before moving?
26. What would you do differently if you moved again?

### Section E — Product willingness to pay
27. Would you pay for a tool that compares countries based on your personal goals?
28. Would you pay for a verified country report?
29. Would you pay for alerts about visa/legal/tax changes?
30. Would you pay for a document checklist tailored to your nationality and goal?
31. Would you pay for access to verified real experiences from people with a similar profile?
32. What price would feel acceptable?
33. What would make you trust such a product?
34. What would make you refuse to pay?

## Survey questions

Use a 1-5 scale unless noted.

1. I found it difficult to compare countries objectively.
2. I found visa/residence information confusing.
3. I worried that information was outdated.
4. I trusted official sources more than community sources.
5. I trusted people with recent first-hand experience more than generic articles.
6. I wanted a personalised recommendation, not just country articles.
7. I would pay for a verified relocation checklist.
8. I would pay for legal/rule-change alerts.
9. I would pay for a country comparison dashboard.
10. I would pay for access to verified case studies.

Multiple choice:

- Main goal: work / family / study / business / investment / passport / safety / lifestyle / remote work / retirement.
- Main fear: visa denial / money loss / wrong country / housing / healthcare / taxes / safety / bureaucracy / isolation.
- Most used sources: Google / YouTube / Reddit / Telegram / Facebook / official websites / lawyer / friends / blogs / paid consultant.
- Preferred output: dashboard / PDF report / AI chat / checklist / map / expert call / forum / email alerts.

## Coding tags for answers

Use these tags when analysing interviews:

- VISA_CONFUSION
- LAW_CHANGED
- OUTDATED_INFO
- CONTRADICTORY_ADVICE
- COST_UNCERTAINTY
- HOUSING_RISK
- TAX_RISK
- BANKING_RISK
- SAFETY_FEAR
- FAMILY_NEEDS
- SCHOOL_HEALTHCARE
- TRUST_GAP
- COMMUNITY_HELPFUL
- COMMUNITY_NOISY
- PAID_CONSULTANT_USED
- WOULD_PAY_REPORT
- WOULD_PAY_ALERTS
- WOULD_PAY_CHECKLIST
- WOULD_PAY_AI

## Expected insight output

Final user-research report should include:

1. Top 10 user pains.
2. Top 10 trusted sources.
3. Top 10 untrusted/confusing sources.
4. Most common comparison pairs.
5. Most common paid services used.
6. Willingness-to-pay ranges by segment.
7. Product features users explicitly requested.
8. Features users considered unnecessary.


---


# Legal Source Map for Priority Countries

## Purpose

This file lists official or high-confidence sources for collecting visa, residence, citizenship, law and policy-change information. It is a starting source map, not legal advice.

## Source quality tiers

- **Tier 1:** official government, immigration authority, tax authority, parliament, official gazette, EU legal database.
- **Tier 2:** recognised international organisations, official investment agencies, official consular pages.
- **Tier 3:** law-firm guides, relocation agencies, community reports. Use only as interpretation or practical signal, never as primary rule.

## Priority country source map

| Country / region | Immigration / visa source | Law / policy source | Tax / business source | Notes for product monitoring |
|---|---|---|---|---|
| United States | USCIS: https://www.uscis.gov/ | Congress.gov: https://www.congress.gov/; Federal Register: https://www.federalregister.gov/ | IRS: https://www.irs.gov/ | Strong official sources and APIs, but immigration law is complex and category-specific. |
| Canada | IRCC / Canada.ca immigration: https://www.canada.ca/en/services/immigration-citizenship.html | Justice Laws: https://laws-lois.justice.gc.ca/ | CRA: https://www.canada.ca/en/revenue-agency.html | Track Express Entry, provincial programmes and temporary public policies. |
| United Kingdom | GOV.UK visas and immigration: https://www.gov.uk/browse/visas-immigration | legislation.gov.uk: https://www.legislation.gov.uk/ | HMRC: https://www.gov.uk/government/organisations/hm-revenue-customs | Good official guidance; frequent rule/fee changes require date-stamped monitoring. |
| European Union | EU Migration and Home Affairs: https://home-affairs.ec.europa.eu/ | EUR-Lex: https://eur-lex.europa.eu/; N-Lex: https://n-lex.europa.eu/ | European Commission taxation: https://taxation-customs.ec.europa.eu/ | EU-level law plus national law must be separated. |
| Portugal | AIMA: https://aima.gov.pt/; national visas: https://vistos.mne.gov.pt/ | Diário da República: https://diariodarepublica.pt/ | Autoridade Tributária: https://www.portaldasfinancas.gov.pt/ | High priority due to residence, nationality and tax changes. |
| Spain | Ministerio de Inclusión / immigration portal: https://www.inclusion.gob.es/ | BOE: https://www.boe.es/ | Agencia Tributaria: https://sede.agenciatributaria.gob.es/ | Track digital nomad/startup law, residence, tax residency and regional variation. |
| Uruguay | Gub.uy residence procedures: https://www.gub.uy/tramites/residencia-legal; Interior Ministry residency FAQ: https://www.gub.uy/ministerio-interior/ | IMPO official gazette/laws: https://www.impo.com.uy/ | DGI: https://www.dgi.gub.uy/; Uruguay XXI: https://www.uruguayxxi.gub.uy/ | High priority for residence, citizenship interpretation, tax and investor friendliness. |
| Argentina | Dirección Nacional de Migraciones: https://www.argentina.gob.ar/migraciones; Cancillería visas: https://cancilleria.gob.ar/en/visas | InfoLEG: http://servicios.infoleg.gob.ar/ | AFIP/ARCA official tax portal: https://www.afip.gob.ar/ | High volatility; track migration decrees, exchange/tax changes and residence categories. |
| Paraguay | Dirección Nacional de Migraciones: https://migraciones.gov.py/ | Biblioteca y Archivo Central del Congreso: https://www.bacn.gov.py/ | SET / DNIT: https://www.dnit.gov.py/ | Important for low-cost residence/citizenship interest; verify rules against Law 6984/2022 and regulations. |
| Chile | Servicio Nacional de Migraciones: https://serviciomigraciones.cl/ | Ley Chile: https://www.bcn.cl/leychile/ | Servicio de Impuestos Internos: https://www.sii.cl/ | Track visa categories, regularisation, taxes and political/legal changes. |
| Mexico | Instituto Nacional de Migración: https://www.inm.gob.mx/ | Cámara de Diputados legal database: https://www.diputados.gob.mx/LeyesBiblio/ | SAT: https://www.sat.gob.mx/ | Useful for residency, lifestyle migration, remote workers and company formation. |
| Serbia | Ministry of Interior / foreigners: https://www.mup.gov.rs/ | Official Gazette: https://www.pravno-informacioni-sistem.rs/ | Tax Administration: https://www.purs.gov.rs/ | Track temporary residence, entrepreneurship and regional geopolitics. |
| Georgia | Public Service Hall / residence: https://psh.gov.ge/; Migration Commission: https://migration.commission.ge/ | Legislative Herald: https://matsne.gov.ge/ | Revenue Service: https://www.rs.ge/ | Important for entrepreneurs, low tax and regional relocation. |
| Armenia | Migration and Citizenship Service: https://migration.e-gov.am/ | Armenian Legal Information System: https://www.arlis.am/ | State Revenue Committee: https://www.src.am/ | Track residence, citizenship, business and regional risk. |
| Turkey | Presidency of Migration Management: https://en.goc.gov.tr/ | Official Gazette: https://www.resmigazete.gov.tr/ | Revenue Administration: https://www.gib.gov.tr/ | Track residence permit tightening, property rules and citizenship investment. |
| United Arab Emirates | ICP: https://icp.gov.ae/; Dubai GDRFA: https://www.gdrfad.gov.ae/ | UAE Legislation: https://uaelegislation.gov.ae/ | Federal Tax Authority: https://tax.gov.ae/ | High business/remote-worker/investor relevance; emirate-level differences matter. |
| Netherlands | IND residence permits: https://ind.nl/en/residence-permits | wetten.nl: https://wetten.overheid.nl/ | Belastingdienst: https://www.belastingdienst.nl/ | Useful benchmark for EU skilled migration, study/work residence and highly skilled migrants. |

## Recommended monitoring fields

For each source, store:

- country;
- source name;
- source type;
- URL;
- language;
- update frequency;
- last checked date;
- affected user scenario;
- legal category;
- summary;
- confidence level;
- whether expert review is required.

## Legal signal classification

Every detected legal/policy update should be classified as:

- migration access;
- residence renewal;
- permanent residence;
- citizenship/naturalisation;
- digital nomad / remote work;
- tax residency;
- company formation;
- banking / AML / KYC;
- property rights / foreign ownership;
- family reunification;
- student pathway;
- work permit;
- public safety / civil liberties;
- rule of law / courts;
- political rights / institutional direction.

## Product warning

The platform should never present legal-source summaries as final legal advice. It should show source links, dates, confidence levels and “professional review recommended” markers for high-stakes decisions.


---


# Monetisation Benchmark and Pricing Signals

## Purpose

This file summarises how adjacent platforms monetise migration, relocation, country-data, community, legal tracking and global mobility products.

## Main monetisation categories

| Model | Typical buyer | What is sold | Examples / pattern | Relevance |
|---|---|---|---|---|
| Advertising | Free users, advertisers | Attention and targeted traffic | Google, YouTube, Reddit, Numbeo-style content pages | Useful for traffic, but can weaken trust if overused. |
| Affiliate | Consumers | Referrals to insurance, visas, money transfer, housing, banks, consultants | Visa services, travel insurance, relocation content sites | Strong if transparent; risky if recommendations become biased. |
| Freemium membership | Consumers/community users | Basic free access; paid community/events/features | InterNations Basic vs paid memberships | Good for community, alerts, saved comparisons. |
| Paid one-off access | Consumers | Lifetime/membership access, reports, guides | Nomads.com membership-style access; paid country reports | Good for early cash flow. |
| Paid reports | Consumers, investors, companies | Country reports, risk reports, visa/residence analysis | Henley, Global Citizen Solutions, EIU-style reports | High trust required; strong for serious users. |
| Consultation marketplace | Consumers | Calls with lawyers, tax advisers, relocation consultants | Citizen Remote-style support, immigration consultants | High willingness to pay; requires vetting and liability controls. |
| Document/checklist tools | Consumers | Personalised checklists, templates, application tracking | Visa tech and relocation platforms | Strong B2C utility. |
| Alerts/watchlists | Consumers and B2B | Legal, visa, tax and country-risk alerts | FiscalNote/PolicyNote, Crisis24, International SOS | Very relevant to country direction platform. |
| B2B SaaS | Companies, HR, global mobility teams | Relocation workflows, compliance, employee mobility | Localyze, Jobbatical, Deel, Remote, Cartus, Equus | Strong revenue but different buyer and longer sales cycle. |
| API/data access | Developers, analysts, companies | Structured data feeds | FiscalNote API, Numbeo data/API-like products, travel requirement APIs | Strong long-term model if data quality is defensible. |

## Competitor monetisation signals

| Platform type | Monetisation signal | Notes |
|---|---|---|
| Digital nomad ranking/community | Membership fees + advertising | Nomads.com states it mostly makes money from website membership fees and company advertising. |
| Expat community | Free basic membership + paid membership/events | InterNations offers Basic, Albatross and InterNations One membership models; paid costs vary by location and subscription period. |
| Visa processing | Service fees | iVisa, Atlys, VFS/TLS-style flows monetise transaction handling and convenience. |
| Immigration advisory | Consultation/project fees | Henley, Global Citizen Solutions, Nomad Capitalist and Citizen Remote use advisory/service funnels. |
| Cost-of-living databases | Ads, data, API/commercial use | Numbeo-style data products can serve consumers and organisations. |
| Public affairs/legal tracking | Enterprise subscriptions/API | FiscalNote and Quorum show the B2B value of tracking legislation, alerts, AI summaries and workflows. |
| Travel/security risk | Enterprise subscriptions/services | International SOS, Crisis24, Riskline-style products monetise alerts and risk intelligence. |
| Global mobility HR | Enterprise SaaS/service fees | Localyze, Jobbatical, Deel, Remote, Oyster and similar platforms monetise employer workflows. |

## Recommended monetisation ladder for a new product

### Stage 1 — Free discovery layer
- Free country cards.
- Free limited comparison.
- Free article-style country briefs.
- Free public legal-signal feed with limited history.

Goal: SEO, trust, data collection, audience building.

### Stage 2 — Consumer premium
- Saved country shortlist.
- Full comparison dashboard.
- Scenario-based country fit score.
- Personalised relocation checklist.
- PDF country report export.
- Legal/tax/visa change watchlist.
- Alerts for selected countries.

Possible pricing experiment:

- $9-15/month for light users.
- $19-39/month for serious planners.
- $49-99 one-off country report.
- $99-299 personalised relocation decision report.

These are hypotheses, not validated prices.

### Stage 3 — Expert marketplace
- Paid calls with immigration lawyers, tax advisers, relocation consultants, school consultants, banking specialists.
- Platform takes commission or listing fee.
- Requires verification, disclaimers and jurisdiction controls.

### Stage 4 — B2B/API layer
- Data feeds for country-risk, legal-signal, visa-change and migration-interest indicators.
- Dashboards for HR/global mobility teams, investors, relocation agencies, universities and immigration firms.
- API access to structured country indicators.

### Stage 5 — Strategic intelligence
- Premium country direction reports.
- Legal drift monitoring.
- Investor/business migration briefings.
- Regional trend reports.

## What users are most likely to pay for

1. Reducing legal/document mistakes.
2. Understanding which country fits their exact profile.
3. Avoiding outdated or contradictory advice.
4. Alerts when visa/tax/residence rules change.
5. Verified real-life cases from similar users.
6. A personalised checklist and timeline.
7. A professional-grade country comparison report.
8. Access to vetted experts.

## Risks

1. If monetisation relies too much on affiliates, trust may fall.
2. If legal information is monetised without review, liability risk rises.
3. If community is free but unstructured, quality may collapse.
4. If premium features are too generic, users will keep using Google/Telegram for free.

## Best strategic model

The strongest model is likely a hybrid:

- free public country intelligence for acquisition;
- premium personal scenario analysis for B2C revenue;
- paid alerts and reports for serious users;
- expert marketplace for high-intent cases;
- B2B/API data products later.


---


# Country Risk and Direction Index Methodology

## Purpose

This file defines how to convert scattered country information into a structured country-direction model.

The goal is not to say whether a country is “good” or “bad”. The goal is to measure whether a country is becoming more or less suitable for a specific scenario.

## Core concept

A country should be evaluated through two dimensions:

1. **Current state** — how attractive or risky the country is today.
2. **Direction / drift** — whether it is improving, worsening or becoming more uncertain.

## Recommended dimensions

| Dimension | Description | Example sources |
|---|---|---|
| Migration openness | Ease of entering, staying, renewing, naturalising | Immigration authorities, visa portals, legal updates |
| Citizenship pathway | Clarity and speed of citizenship route | Nationality law, official guidance, lawyer interpretation |
| Legal stability | Predictability of rules and institutions | Rule of law indices, official legal changes, WJP |
| Political direction | Liberalisation vs authoritarianisation, stability vs volatility | V-Dem, Freedom House, EIU, news/legal signals |
| Business friendliness | Company formation, taxes, bureaucracy, property rights | Tax authorities, World Bank/OECD, Heritage/Fraser, local law |
| Cost pressure | Inflation, rent pressure, living costs | Numbeo, official inflation data, housing portals |
| Social acceptance | Attitudes toward migrants, discrimination, integration | Surveys, community reports, hate-crime data, forums |
| Safety/security | Crime, conflict, unrest, travel risk | Travel advisories, crime stats, Crisis24/Riskline-style sources |
| Human infrastructure | Healthcare, schools, banking, transport, digital services | Official data, user reports, OECD/UN indicators |
| Data confidence | How fresh and verifiable the evidence is | Source metadata, last checked date, number of sources |

## Signal types

Every update should become a signal:

- Legal signal
- Policy signal
- Economic signal
- Social signal
- Safety signal
- Community signal
- Market signal
- Search-demand signal

## Signal fields

| Field | Description |
|---|---|
| signal_id | Unique identifier |
| country | Country affected |
| date_detected | Date signal was found |
| effective_date | Date rule/change takes effect, if known |
| source_url | Primary source |
| source_type | Official / media / legal expert / community / data |
| scenario_affected | Migration / business / investment / family / study / nomad / citizenship |
| impact_direction | Positive / negative / mixed / uncertain |
| impact_strength | Low / medium / high / critical |
| confidence | Low / medium / high |
| summary | Plain-language summary |
| original_text_excerpt | Short excerpt, if legally allowed |
| review_status | Unreviewed / editor-reviewed / expert-reviewed |

## Scoring logic

Use two scores:

### 1. Country Fit Score
A scenario-specific score for the user.

Example formula:

`Country Fit Score = weighted sum of scenario indicators - weighted risk penalties`

Weights differ by scenario.

Example: fast citizenship user:

- citizenship pathway: 35%
- residence simplicity: 20%
- legal stability: 15%
- cost of living: 10%
- tax/business environment: 10%
- community evidence: 10%

Example: entrepreneur:

- business friendliness: 30%
- tax predictability: 20%
- banking/company formation: 15%
- residence pathway: 15%
- political/legal stability: 15%
- cost of living: 5%

### 2. Country Direction Score
A trend score measuring whether conditions are improving or deteriorating.

Possible output:

- Strongly improving
- Improving
- Stable
- Mixed/uncertain
- Deteriorating
- Strongly deteriorating

## Explainability rule

Every score must answer:

1. Why did the country receive this score?
2. Which sources support it?
3. Which recent changes affected it?
4. How confident is the system?
5. What would change the score in the future?

## Example direction interpretation

### Migration openness: deteriorating
Evidence pattern:

- higher income requirements;
- longer processing times;
- stricter renewal rules;
- reduced pathways for low-income applicants;
- anti-immigration political rhetoric;
- negative recent user cases.

### Business friendliness: improving
Evidence pattern:

- simplified company formation;
- lower or clearer tax rules;
- digital government services;
- startup/talent visa expansion;
- stronger property-rights indicators;
- positive founder reports.

## Confidence model

| Confidence level | Conditions |
|---|---|
| High | Official source + recent date + expert/editor review + corroborating evidence |
| Medium | Official source or strong secondary source but interpretation uncertain |
| Low | Community reports only, old information, conflicting evidence |

## Product implication

The unique product layer is not the raw data itself. The unique layer is:

`raw source -> structured signal -> scenario impact -> country direction -> explainable user recommendation`


---


# MVP Readiness Decision Memo

## Decision

The research archive is ready for MVP planning.

Do not continue broad general research. The next step should be a focused product strategy and technical design phase.

## Recommended MVP positioning

A country intelligence and decision-support platform for people choosing a country for relocation, residence, citizenship, remote work, business or investment.

The MVP should not try to cover all countries and all user types. It should prove one workflow:

`User goal -> shortlist countries -> compare objective data -> inspect legal signals -> read structured human experiences -> receive scenario-specific recommendation.`

## Recommended first countries

Start with 12-15 countries where demand, migration interest, data availability and scenario variety are strong:

1. Uruguay
2. Argentina
3. Paraguay
4. Portugal
5. Spain
6. Serbia
7. Georgia
8. Armenia
9. Turkey
10. UAE
11. Mexico
12. Chile
13. Canada
14. Netherlands
15. United Kingdom or United States as benchmark countries

## Recommended first scenarios

1. Fast residence / citizenship pathway.
2. Low-cost long-term life.
3. Remote worker / digital nomad relocation.
4. Business formation / entrepreneur relocation.
5. Family relocation with safety, healthcare and education.

## MVP feature set

### Must-have

- Country cards.
- Country comparison table.
- Scenario-based scoring.
- Legal signal feed.
- Source links and date stamps.
- Basic cost-of-living and safety indicators.
- Structured user experience form.
- Admin/editor interface for country data and legal signals.
- Saved country shortlist.

### Should-have

- Radar charts / scorecards.
- Timeline of legal and policy changes.
- AI summary of country profile.
- Confidence levels for data.
- Exportable comparison report.
- Watchlist for countries.

### Later

- Browser extension.
- Mobile app.
- Expert marketplace.
- Full community/forum.
- API/data product.
- Paid alerts.
- Advanced AI chat assistant.
- Automated government-source monitoring.

## MVP data entities

Minimum entities:

- Country
- City
- Scenario
- Indicator
- CountryIndicatorValue
- LegalSignal
- Source
- EvidenceItem
- UserExperience
- UserProfile
- CountryComparison
- CountryFitScore
- CountryDirectionScore
- WatchlistItem

## MVP risks

1. Legal data may become outdated quickly.
2. Scores may be distrusted if methodology is hidden.
3. User-generated content may become noisy if unstructured.
4. Too many countries will dilute quality.
5. Too many user scenarios will delay launch.
6. Affiliate monetisation may create perceived bias.

## MVP success metrics

- Users create country comparisons.
- Users save country shortlists.
- Users return to check legal signals.
- Users submit structured experiences.
- Users export/share reports.
- Users sign up for alerts.
- Users say the product reduced research time.
- Users say the product revealed risks they had missed.

## Recommended next documents

1. Product Strategy Document.
2. MVP Functional Specification.
3. Data Model Specification.
4. Country Card Schema.
5. Legal Signal Schema.
6. Scoring Methodology v0.1.
7. UX Sitemap.
8. OpenAPI Contract Foundation.


---


# Source Index — Final Gap Completion Pack

## Macro migration and displacement

- UN DESA, International Migrant Stock 2024: https://www.un.org/development/desa/pd/content/international-migrant-stock-2024-key-facts-and-figures
- UN DESA PDF, International Migrant Stock 2024 key facts: https://www.un.org/development/desa/pd/sites/www.un.org.development.desa.pd/files/undesa_pd_2025_intlmigstock_2024_key_facts_and_figures_advance-unedited.pdf
- Migration Data Portal, International migrant stocks: https://www.migrationdataportal.org/themes/international-migrant-stocks-overview
- OECD, International Migration Outlook 2025: https://www.oecd.org/en/publications/2025/11/international-migration-outlook-2025_355ae9fd.html
- UNHCR Global Trends: https://www.unhcr.org/global-trends
- UNHCR Global Trends US page: https://www.unhcr.org/us/global-trends
- Gallup migration topic: https://news.gallup.com/topic/migration.aspx
- Gallup, Desire to Move Permanently to U.S. at New Low: https://news.gallup.com/poll/708614/desire-migrate-drops-new-low.aspx

## Search demand and methodology

- Google Trends: https://trends.google.com/trends/
- Google Trends data FAQ: https://support.google.com/trends/answer/4365533
- Google Trends API alpha: https://developers.google.com/search/apis/trends
- Google Search Central, Introducing the Google Trends API alpha: https://developers.google.com/search/blog/2025/07/trends-api
- Google Keyword Planner: https://ads.google.com/home/tools/keyword-planner/
- Google Ads help, Keyword Planner: https://support.google.com/google-ads/answer/7337243

## Competitor and platform references

- Nomads.com: https://nomads.com/
- Nomads.com FAQ: https://nomads.com/faq
- Nomads.com monetisation FAQ: https://nomads.com/faq/how-does-nomadscom-make-money-2529406
- Numbeo Cost of Living: https://www.numbeo.com/cost-of-living/
- Numbeo common/about: https://www.numbeo.com/common/
- Expat.com: https://www.expat.com/
- Expat.com housing: https://www.expat.com/en/housing/
- InterNations: https://www.internations.org/
- InterNations membership options: https://support.internations.org/hc/en-us/articles/360010689157-What-are-different-membership-options
- InterNations paid membership cost: https://support.internations.org/hc/en-us/articles/360010695097-What-is-the-cost-of-a-paid-membership
- InterNations Expat Insider: https://www.internations.org/expat-insider
- VisaGuide.World: https://visaguide.world/
- VisaGuide.World About: https://visaguide.world/about-us/
- Passport Index: https://www.passportindex.org/
- Henley Passport Index: https://www.henleyglobal.com/passport-index
- Citizen Remote: https://citizenremote.com/
- FiscalNote Policy Tracker: https://fiscalnote.com/solutions/policy-tracker
- FiscalNote Global Policy Tracking: https://fiscalnote.com/solutions/global-policy-tracking
- FiscalNote PolicyNote API/product: https://fiscalnote.com/products/policynote
- Quorum: https://www.quorum.us/
- Quorum pricing: https://www.quorum.us/pricing/

## Official legal and immigration sources

- USCIS: https://www.uscis.gov/
- Canada immigration and citizenship: https://www.canada.ca/en/services/immigration-citizenship.html
- UK visas and immigration: https://www.gov.uk/browse/visas-immigration
- UKVI organisation: https://www.gov.uk/government/organisations/uk-visas-and-immigration
- EUR-Lex: https://eur-lex.europa.eu/
- N-Lex: https://n-lex.europa.eu/
- Portugal AIMA: https://aima.gov.pt/
- Portugal national visas: https://vistos.mne.gov.pt/
- Uruguay legal residence: https://www.gub.uy/tramites/residencia-legal
- Uruguay residency FAQ: https://www.gub.uy/ministerio-interior/comunicacion/publicaciones/frequently-asked-questions-about-uruguayan-residency/frequently-asked-0
- Argentina visas: https://cancilleria.gob.ar/en/visas
- Argentina residencies: https://www.argentina.gob.ar/migraciones/residencias
- Paraguay Migraciones: https://migraciones.gov.py/
- Paraguay temporary residence: https://migraciones.gov.py/residencia-temporal/
- Paraguay online visas: https://www.mre.gov.py/visasenlinea/
- Netherlands IND residence permits: https://ind.nl/en/residence-permits

## Governance, freedom and country direction sources

- Freedom House: https://freedomhouse.org/
- V-Dem: https://www.v-dem.net/
- World Justice Project Rule of Law Index: https://worldjusticeproject.org/rule-of-law-index/
- Transparency International CPI: https://www.transparency.org/
- OECD Better Life Index: https://www.oecdbetterlifeindex.org/
- Our World in Data: https://ourworldindata.org/
- World Bank Data: https://data.worldbank.org/
- World Bank Worldwide Governance Indicators: https://www.worldbank.org/en/publication/worldwide-governance-indicators
