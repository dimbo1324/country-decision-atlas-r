# Source Index — Final Gap Completion Pack

## Macro migration and displacement

- UN DESA, International Migrant Stock 2024: https://www.un.org/development/desa/pd/content/international-migrant-stock-2024-key-facts-and-figures
- UN DESA PDF, International Migrant Stock 2024 key facts: https://www.un.org/development/desa/pd/sites/www.un.org.development.desa.pd/files/undesa_pd_2025_intlmigstock_2024_key_facts_and_figures_advance-unedited.pdf
- Migration Data Portal, International migrant stocks: https://www.migrationdataportal.org/themes/international-migrant-stocks-overview
- OECD, International Migration Outlook 2025: https://www.oecd.org/en/publications/2025/11/international-migration-outlook-2025_355ae9fd.html
- UNHCR Global Trends: https://www.unhcr.org/global-trends
- UNHCR Global Trends US page: https://www.unhcr.org/us/global-trends
- Gallup migration topic: https://news.gallup.com/topic/migration.aspx
- Gallup, Desire to Move Permanently to U.S. at New Low: https://news.gallup.com/poll/708614/desire-migrate-drops-new-low.aspx

## Search demand and methodology

- Google Trends: https://trends.google.com/trends/
- Google Trends data FAQ: https://support.google.com/trends/answer/4365533
- Google Trends API alpha: https://developers.google.com/search/apis/trends
- Google Search Central, Introducing the Google Trends API alpha: https://developers.google.com/search/blog/2025/07/trends-api
- Google Keyword Planner: https://ads.google.com/home/tools/keyword-planner/
- Google Ads help, Keyword Planner: https://support.google.com/google-ads/answer/7337243

## Competitor and platform references

- Nomads.com: https://nomads.com/
- Nomads.com FAQ: https://nomads.com/faq
- Nomads.com monetisation FAQ: https://nomads.com/faq/how-does-nomadscom-make-money-2529406
- Numbeo Cost of Living: https://www.numbeo.com/cost-of-living/
- Numbeo common/about: https://www.numbeo.com/common/
- Expat.com: https://www.expat.com/
- Expat.com housing: https://www.expat.com/en/housing/
- InterNations: https://www.internations.org/
- InterNations membership options: https://support.internations.org/hc/en-us/articles/360010689157-What-are-different-membership-options
- InterNations paid membership cost: https://support.internations.org/hc/en-us/articles/360010695097-What-is-the-cost-of-a-paid-membership
- InterNations Expat Insider: https://www.internations.org/expat-insider
- VisaGuide.World: https://visaguide.world/
- VisaGuide.World About: https://visaguide.world/about-us/
- Passport Index: https://www.passportindex.org/
- Henley Passport Index: https://www.henleyglobal.com/passport-index
- Citizen Remote: https://citizenremote.com/
- FiscalNote Policy Tracker: https://fiscalnote.com/solutions/policy-tracker
- FiscalNote Global Policy Tracking: https://fiscalnote.com/solutions/global-policy-tracking
- FiscalNote PolicyNote API/product: https://fiscalnote.com/products/policynote
- Quorum: https://www.quorum.us/
- Quorum pricing: https://www.quorum.us/pricing/

## Official legal and immigration sources

- USCIS: https://www.uscis.gov/
- Canada immigration and citizenship: https://www.canada.ca/en/services/immigration-citizenship.html
- UK visas and immigration: https://www.gov.uk/browse/visas-immigration
- UKVI organisation: https://www.gov.uk/government/organisations/uk-visas-and-immigration
- EUR-Lex: https://eur-lex.europa.eu/
- N-Lex: https://n-lex.europa.eu/
- Portugal AIMA: https://aima.gov.pt/
- Portugal national visas: https://vistos.mne.gov.pt/
- Uruguay legal residence: https://www.gub.uy/tramites/residencia-legal
- Uruguay residency FAQ: https://www.gub.uy/ministerio-interior/comunicacion/publicaciones/frequently-asked-questions-about-uruguayan-residency/frequently-asked-0
- Argentina visas: https://cancilleria.gob.ar/en/visas
- Argentina residencies: https://www.argentina.gob.ar/migraciones/residencias
- Paraguay Migraciones: https://migraciones.gov.py/
- Paraguay temporary residence: https://migraciones.gov.py/residencia-temporal/
- Paraguay online visas: https://www.mre.gov.py/visasenlinea/
- Netherlands IND residence permits: https://ind.nl/en/residence-permits

## Governance, freedom and country direction sources

- Freedom House: https://freedomhouse.org/
- V-Dem: https://www.v-dem.net/
- World Justice Project Rule of Law Index: https://worldjusticeproject.org/rule-of-law-index/
- Transparency International CPI: https://www.transparency.org/
- OECD Better Life Index: https://www.oecdbetterlifeindex.org/
- Our World in Data: https://ourworldindata.org/
- World Bank Data: https://data.worldbank.org/
- World Bank Worldwide Governance Indicators: https://www.worldbank.org/en/publication/worldwide-governance-indicators
