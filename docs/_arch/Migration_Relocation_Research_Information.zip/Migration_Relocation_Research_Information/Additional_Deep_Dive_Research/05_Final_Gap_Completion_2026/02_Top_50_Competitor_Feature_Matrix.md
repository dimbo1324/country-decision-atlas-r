# Top 50 Competitor Feature Matrix

**Purpose:** identify which functions are already covered by existing platforms and where a new country-choice / relocation-intelligence product can differentiate.

**How to read this matrix:**

- “Comparison” means a platform supports meaningful country/city/passport/program comparison.
- “Community” means users can publish experience, reviews, posts, comments or forum answers.
- “Legal tracking” means the platform monitors laws, visa rules, policy changes, regulations or legal databases in a systematic way.
- “Reuse signal” identifies what can be ethically learned from the product pattern without copying the product.

## Matrix

| # | Platform | Category | Primary user | Core job | Key strength | Main weakness / gap | Comparison | Community | Legal tracking | Monetisation | Reuse signal |
|---:|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Google Search | General discovery | Anyone researching relocation | Find scattered information quickly | Universal reach, fresh SERPs | No structured decision workflow; high noise | No | No | No | Ads | SEO demand and source-discovery logic |
| 2 | YouTube | Video experience | Migrants, nomads, travellers | Understand lived experience visually | High trust through personal stories | Subjective, not structured, hard to compare | No | Creator comments | No | Ads / creator monetisation | Video evidence layer and creator-source ingestion |
| 3 | Reddit | Community Q&A | Relocants, expats, nomads | Ask real people niche questions | Authentic discussions, long-tail problems | Unverified, biased, often contradictory | No | Yes | No | Ads / premium | Pain mining and structured Q&A ideas |
| 4 | Telegram | Community/chat | Migrants by country/language | Get fast local updates | Real-time informal info | Hard to search, noisy, unverifiable | No | Yes | No | Mostly indirect | Early-warning social signal source |
| 5 | Facebook Groups | Community | Local expats and migrants | Find groups, housing, advice | Large local groups | Fragmented, moderation varies | No | Yes | No | Ads | Local community segmentation |
| 6 | Google Maps | Local discovery | Travellers, movers, families | Evaluate neighbourhoods and services | Local reviews, maps, infrastructure | Not relocation-specific | Partial | Reviews | No | Ads/local listings | Neighbourhood evidence layer |
| 7 | Wikipedia | Reference | General researchers | Understand country basics | Broad coverage, citations | Not personalised or current enough | No | No | Partial law links | Donations | Country profile baseline |
| 8 | TripAdvisor | Travel reviews | Travellers, short-term visitors | Assess places and services | Large review base | Tourism-biased | No | Reviews | No | Ads/booking affiliate | Review trust mechanics |
| 9 | Booking.com | Accommodation marketplace | Travellers, temporary movers | Book temporary housing | Inventory and reviews | Not long-term relocation logic | No | Reviews | No | Commission | Short-stay relocation bridge |
| 10 | Airbnb | Accommodation marketplace | Travellers, nomads, trial movers | Test living in a place | Neighbourhood and lifestyle signals | Expensive, short-term bias | No | Reviews | No | Commission | Try-before-moving journey |
| 11 | Nomads.com / Nomad List | Digital nomad city ranking | Digital nomads, remote workers | Choose city to live/work remotely | Strong city filters, community, travel tracking | Nomad-focused, not full migration/law platform | Yes | Community | Limited / user reports | Membership + ads | Interactive scoring, filters, calendar/residency alerts |
| 12 | Numbeo | Cost/quality database | Individuals, researchers, organisations | Compare cost of living and quality indicators | Massive crowdsourced price database | Crowdsourced accuracy varies; no personal scenario | Yes | Data contributors | No | Ads/API/data products | Crowdsourced quantitative indicators |
| 13 | Expatistan | Cost of living | Expats, movers | Compare city costs | Simple cost comparison | Limited broader country-choice depth | Yes | Contributors | No | Ads/data | Cost-comparison simplicity |
| 14 | Livingcost.org | Cost of living | Expats, students, travellers | Estimate living costs | Simple country/city cost data | Limited legal/community layer | Yes | Limited | No | Ads | Low-friction benchmark pages |
| 15 | MyLifeElsewhere | Country comparison | General users | Compare countries and cities | Accessible comparative format | Not deep enough for serious decisions | Yes | No | No | Ads | Friendly comparison UX |
| 16 | Teleport Cities | City matching | Tech workers, movers | Choose city for career/lifestyle | Personal city matching and quality metrics | Limited coverage/current activity | Yes | No | No | Previously SaaS/ecosystem | Scenario matching idea |
| 17 | The Earth Awaits | Budget-based city search | Budget-conscious movers | Find places by budget and preferences | Clear budget-first filters | Limited legal/community data | Yes | No | No | Likely ads/donations | Budget-first exploration |
| 18 | Where Can I Live | Immigration pathways | Individuals seeking visa/residence options | Find where one can live by passport/status | Strong immigration-pathway framing | Data freshness/coverage must be checked | Yes | No | Immigration info | Content/affiliate/services | Passport-to-residence eligibility logic |
| 19 | VisaGuide.World | Visa information | Travellers and migrants | Understand visa requirements | Broad visa guides and news | Information guide, not personalised platform | Partial | No | Visa/news updates | Ads/affiliate possible | Visa guide content structure |
| 20 | VisaDB | Visa database | Travellers, nomads | Check visa options and travel freedom | Structured visa database | Limited decision/intelligence layer | Yes | No | Visa data | Subscription/paid access historically | Visa filters |
| 21 | iVisa | Visa processing | Travellers | Apply for visas/eVisas online | Transactional visa application flow | Travel-document focus, not country choice | No | Reviews | No | Service fees | Document/application workflow |
| 22 | Atlys | Visa processing app | Travellers | Apply for visas via mobile-first process | Strong UX around visa application | Not broad relocation strategy | No | Reviews | No | Service fees | Mobile-first document flow |
| 23 | Sherpa | Travel requirements API | Travellers, airlines, travel companies | Check entry requirements | Strong B2B/API travel compliance | Short-term travel focus | No | No | Entry rules | B2B/API | Rules engine and API model |
| 24 | VFS Global | Visa centres | Visa applicants, governments | Submit applications/biometrics | Official outsourced visa infrastructure | Not advisory/comparison product | No | No | No | Government/consular contracts + fees | Appointment/document workflow |
| 25 | TLScontact | Visa centres | Visa applicants, governments | Visa appointments and processing support | Official consular process layer | Not decision-support | No | No | No | Service fees/contracts | Operational workflow model |
| 26 | Passport Index | Passport ranking | Travellers, mobility researchers | Compare passport mobility | Interactive passport ranking | Mobility only, not relocation suitability | Yes | No | No | Data/brand/ads | Passport power visualisation |
| 27 | Henley Passport Index | Passport ranking | Investors, advisors, researchers | Assess passport mobility | Authoritative passport ranking; 199 passports/227 destinations | Not broader country-choice tool | Yes | No | No | Reports/advisory ecosystem | Mobility index methodology |
| 28 | Henley & Partners | Investment migration advisory | HNWIs, investors | Residence/citizenship by investment | Strong brand, legal/advisory network | High-net-worth niche | No | No | Legal/advisory | Consulting/advisory fees | Premium advisory/report model |
| 29 | Global Citizen Solutions | Investment migration/advisory | Investors, expats | Compare residence/citizenship investment options | Country reports and advisory content | Investor-heavy bias | Partial | No | Program updates | Consulting/reports | Report-led funnel |
| 30 | Nomad Capitalist | Tax/global strategy advisory | Entrepreneurs, HNWIs | Tax, residence, second citizenship strategy | Strong positioning and content marketing | Premium niche, opinionated framing | No | No | Legal/tax content | Consulting/programs | Strategic persona-driven messaging |
| 31 | Citizen Remote | Digital nomad relocation | Remote workers | Get visa and relocation support | End-to-end support across 30+ countries | Remote-worker focus, not universal country atlas | Partial | Testimonials | Visa assistance | Consultations/services | Concierge + platform hybrid |
| 32 | Nomad Embassy | Digital nomad visas | Remote workers | Understand and apply for nomad visas | Clear nomad visa content | Niche to nomads | Partial | No | Visa updates | Affiliate/services | Visa programme comparison |
| 33 | Digital Nomads World | Nomad community/content | Digital nomads | Find guides, community and resources | Lifestyle/community angle | Less rigorous data layer | Partial | Community | No | Membership/ads/affiliate | Community editorial packaging |
| 34 | Freaking Nomads | Nomad media/tools | Digital nomads | Learn destinations and nomad tools | Good content brand | Media not data platform | Partial | No | Visa content | Ads/affiliate | Content funnel ideas |
| 35 | InterNations | Expat community | Expats in major cities | Meet people, events, tips | 420 cities; large trusted network | Community-first, limited structured analytics | No | Yes | No | Freemium/premium events/membership | Trusted community and events model |
| 36 | Expat.com | Expat community/services | Expats and recruiters | Ask questions, read guides, find jobs/housing | Community + jobs + housing + guides | Not deep decision intelligence | Partial | Yes | Visa/life guides | Ads/classifieds/jobs | Multi-sided expat portal model |
| 37 | Expat Exchange | Expat community/content | Expats, retirees | Read country guides and discussions | Long-lived expat knowledge base | Older UX, unstructured content | Partial | Yes | No | Ads/sponsorship | Forum archive value |
| 38 | Expat Forum | Forum | Expats and migrants | Discuss country-specific issues | Focused threads by destination | Noise and outdated posts | No | Yes | No | Ads | Thread taxonomy |
| 39 | Expatica | Country guides/media | Expats in Europe and beyond | Understand visas, housing, healthcare, work | Strong guide format | Content-heavy, not interactive enough | Partial | Limited | Policy/news content | Ads/affiliate | Guide architecture |
| 40 | Expat Arrivals | Country/city guides | Families, expats, employers | Prepare relocation with practical guides | Good practical relocation categories | Limited dynamic scoring | Partial | No | No | Content/business services | Guide taxonomy for families/schools |
| 41 | MoveHub | Moving guides | People moving abroad | Plan move and estimate costs | Accessible relocation content | Not legal-intelligence platform | Partial | No | No | Lead generation/affiliate | Moving-cost funnel |
| 42 | Just Landed | Expat classifieds/guides | Expats | Find housing/jobs/services and advice | Broad expat portal | Fragmented/old UX | Partial | Community | No | Ads/classifieds | Classifieds plus guide model |
| 43 | International Living | Retirement abroad media | Retirees, lifestyle migrants | Identify retirement destinations | Strong niche editorial reports | Retirement/lifestyle bias | Partial | Community/content | No | Subscriptions/reports | Niche audience packaging |
| 44 | World Bank Data | Open data | Researchers, analysts | Get global indicators | Authoritative indicators/API | Not user-friendly decision product | Yes via data | No | No | Public/open | Objective data layer |
| 45 | OECD Better Life Index | Quality of life index | Researchers, public users | Compare wellbeing dimensions | Clear QOL framework | OECD-only coverage | Yes | No | No | Public/open | Indicator category design |
| 46 | Our World in Data | Data visualisation | Researchers, public users | Understand global trends | Excellent charts and transparent sources | Not relocation-specific | Yes via charts | No | No | Donations/grants | Data storytelling |
| 47 | Freedom House | Freedom/democracy index | Researchers, policy users | Assess political rights/civil liberties | Trusted freedom indicators | Not personalised/migration-specific | Yes via scores | No | No | Grants/reports | Freedom score integration |
| 48 | V-Dem | Democracy dataset | Researchers, analysts | Measure democracy/autocracy trends | Deep longitudinal democracy indicators | Complex for consumers | Yes via data | No | No | Research/open data | Country drift methodology |
| 49 | World Justice Project | Rule of law index | Researchers, investors, policy users | Assess rule of law | Strong legal/institutional indicators | Annual, not user-specific | Yes | No | No | Reports/grants | Rule-of-law indicator integration |
| 50 | Transparency International CPI | Corruption index | Public, business, policy users | Assess perceived corruption | Recognised corruption benchmark | Annual and broad | Yes | No | No | Nonprofit/reports | Corruption risk indicator |
| 51 | Economist Intelligence Unit | Country intelligence | Businesses, investors | Analyse country risk, politics, economy | High-quality expert analysis | Expensive, B2B/professional | Yes/reports | No | Policy/economy | Subscriptions/reports | Premium country intelligence format |
| 52 | International SOS | Travel risk/assistance | Corporations, travellers | Manage health/security risk | Operational risk intelligence and assistance | B2B travel-risk focus | Yes/risk | No | Alerts | Enterprise subscription/services | Risk-alert model |
| 53 | Crisis24 | Risk intelligence | Corporations, security teams | Monitor security/travel risks | Real-time alerts and country risk | Enterprise/security focus | Yes/risk | No | Alerts | Enterprise subscription | Alerting and incident feed |
| 54 | FiscalNote / PolicyNote | Policy intelligence | Government affairs teams | Track legislation/regulation and policy changes | AI-driven policy tracking, alerts, API | Enterprise; not relocation-specific | No | No | Yes | Enterprise subscription/API | Legal signal architecture |
| 55 | Quorum | Public affairs software | Policy/public affairs teams | Track legislation and execute advocacy | AI public-affairs workflow, stakeholder tools | Enterprise; not consumer relocation | No | No | Yes | Enterprise subscription | Policy workflow and alerts |
| 56 | LexisNexis | Legal research | Lawyers, compliance teams | Research law and legal/compliance data | Authoritative legal database | Expensive/professional; not consumer UX | No | No | Yes | Subscription | Legal citation/source discipline |

## Main pattern found

No single platform fully combines all of these layers:

1. objective country indicators;
2. visa/residence/citizenship pathways;
3. legal and policy change tracking;
4. structured human relocation experience;
5. personalised scenario matching;
6. explainable scoring;
7. country direction/drift over time;
8. evidence-backed source links;
9. alerts and watchlists.

The strongest product gap remains a hybrid platform that treats country choice as a decision-support workflow, not as a static article, forum, cost table or visa-service funnel.
